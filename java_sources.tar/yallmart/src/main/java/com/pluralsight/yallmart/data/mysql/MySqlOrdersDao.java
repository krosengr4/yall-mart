package com.pluralsight.yallmart.data.mysql;

public class MySqlOrdersDao {
}
